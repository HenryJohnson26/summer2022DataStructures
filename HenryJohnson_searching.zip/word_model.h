//
// Created by htj55 on 7/24/2022.
//

#ifndef MARKOVASSIGNMENT_WORD_MODEL_H
#define MARKOVASSIGNMENT_WORD_MODEL_H

#include "model.h"
#include <map>
#include <vector>
#include <string>
#include <sstream>


class word_model : public markov_model{
public:
    // give the model the example text and the model order; the model
    // should do any preprocessing in this call
    virtual void initialize(string text, int order);

    // produce a text in the style of the example
    virtual string generate(int size);


private:

    //map that holds word data
    map<string, vector<string>> _data;

    int _order;

    string _text;

    vector<string> _allwords;


};


#endif //MARKOVASSIGNMENT_WORD_MODEL_H
