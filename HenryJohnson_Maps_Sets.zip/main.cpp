/*
 * CSCI 262
 *
 * author: Henry Johnson
 *
 * The goal of this program is to take in every word from dictionary.txt
 * then pass it into a map with keys of the length of the word and values of
 * the word, and then ask the user for a lenght of word and reply with a word
 * of that length
 */


#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <fstream>

using namespace std;

int main() {

    ifstream fin("dictionary.txt");
    map<int, vector<string>> length_words;
    string word;
    vector<string> _word;

    length_words[1] = {"a", "i"};
    length_words[2] = {"be", "my", "of", "to"};
    length_words[3] = {"for", "ate", "bar", "may", "sit", "coo"};
    length_words[4] = {"four", "date", "bard", "leaf", "seat", "cool"};

    while (!fin.eof()) {
        getline(fin, word);
        length_words[word.size()].push_back(word);
        //_word.clear();
    }
    fin.close();

    int n = 0;
    while (true) {
        cout << "What length of word do you want? ";
        cin >> n;
        if(length_words.count(n)==0){
            cout<<"I can not supply a word of the requested length"<<endl;
        }
        else {
            cout << "Here's a word: ";
            cout << length_words[n][rand() % length_words[n].size()];
            cout << endl;
        }
    }

    return 0;
}