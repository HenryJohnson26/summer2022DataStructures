//
// Created by htj55 on 7/24/2022.
//

#include "map_model.h"


void map_model::initialize(string text, int order) {
    //make the map, dont forget to wrap around
    //this string is text plus what it would need to wrap around
    string wrapped = text + text.substr(0,order);
    for(int i = 0; i < text.size()-1; i++){
        //map next char to the characters before it
        _data[wrapped.substr(i, order)].push_back(wrapped.at(i+order));
    }

    //setting a string to be used later to find an initial seed
    _text = text;
    _order = order;

}

string map_model::generate(int size) {

    // pick random k-character substring as initial seed
    int start = rand() % (_text.length() - _order);
    string seed = _text.substr(start, _order);

    //string that will be created
    // it will be initialized as seed to find which vector of chars to choosed from
    string out = seed;

    //add a character for size
    for(int i = 0; i < size; i++){

        //select a random character from the vector of the key and add it to the out string
        out+= _data.at(out.substr(i, _order)).at(rand() % _data.at(out.substr(i, _order)).size());
    }
    //return out, minus the original seed
    return out.substr(_order);


}