/*
    Queue.cpp
        
    Method implementations for Queue class

    Queues assignment

    Author: 
*/

/* 
   NOTE: if you prefer, the Queue class is simple enough that you can do all
   of your methods inline. Your choice.

   NOTE that inline means that all of your method definitions can be in the
   header, rather than in this separate .cpp file; inline does not mean all 
   of your code should be on one line!
*/

