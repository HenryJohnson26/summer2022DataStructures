//
// Created by htj55 on 7/24/2022.
//

#ifndef MARKOVASSIGNMENT_MAP_MODEL_H
#define MARKOVASSIGNMENT_MAP_MODEL_H

#include "model.h"
#include <map>
#include <vector>
#include <string>


class map_model : public markov_model{
public:

    virtual void initialize(string text, int order);

    virtual string generate(int size);

private:

    //map that will hold all of our data, it will be <string, vector<char>>
    map<string, vector<char>> _data;

    int _order;

    string _text;

};


#endif //MARKOVASSIGNMENT_MAP_MODEL_H
