//
// Created by htj55 on 7/25/2022.
//

#ifndef HASHTABLE_HASH_H
#define HASHTABLE_HASH_H

#include <list>
#include <vector>
#include <iostream>
#include <string>


using namespace std;

class Hash {

public:
    Hash();
    ~Hash();

    void insertItem(string key);
    void displayTable();

    bool removeItem(string key);

    bool find(string key);

private:
    int _numBuckets;

    vector<list<string>> _table;

    //list<int>* _table;

    int _hashFunction(string x);
};


#endif //HASHTABLE_HASH_H