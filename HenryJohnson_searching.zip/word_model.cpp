//
// Created by htj55 on 7/24/2022.
//

#include "word_model.h"

void word_model::initialize(string text, int order) {

    _order = order;

    istringstream iss(text);
    // to do the wrap around, add the firs order words to the string
    string wrapped = text;
    string word;
    vector<string> allwords;
    for(int i = 0; i<order; i++){
        word = "";
        iss >> word;
        wrapped+=" "+word;
    }
    word = "";
    istringstream iss2(wrapped);
    //create a vector to add all the individual word
    while(iss2>>word){
        allwords.push_back(word);
    }
    string key;
    //itterate through every word
    for(int i = 0;i<allwords.size()-order;i++){
        key = "";
        //generate key
        for(int j = i;j<i+order;j++){
            key+=allwords.at(j) + " ";
        }
        //add key and value
        _data[key].push_back(allwords.at(i+order));
    }

_allwords = allwords;
}

string word_model::generate(int size) {

    // pick random words to be the initial seed
    int start = rand() % (_allwords.size() - _order);
    string seed;
    vector<string> keys;
    for(int i = start; i<start + _order; i++){
        keys.push_back(_allwords.at(i));
    }
    string out;

    //add a random word from the given key
    for(int i = 0;i<size;i++){
        seed = "";
        //take the last order strings from keys, then convert it to a string with spaces after every word
        //add it to seed, then add a random from key seed to out
        //also add the value to keys
        //do that size times
        for(int j = keys.size()-_order;j<keys.size();j++){
            seed+=keys.at(j)+" ";
        }
        string value = _data.at(seed).at(rand() % _data.at(seed).size());
        out+=value+" ";
        keys.push_back(value);
       //from i to i+order in keys, ad a random value of that key
    }
    return out;
}
