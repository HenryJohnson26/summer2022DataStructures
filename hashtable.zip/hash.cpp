//
// Created by htj55 on 7/25/2022.
//

#include "hash.h"


Hash::Hash() {
    int size = 10;
    this->_numBuckets = size;
    _table.resize(size);
}

Hash::~Hash(){
    //delete _table;
}

//insert key into the table
void Hash::insertItem(string key) {
    int index = _hashFunction(key);
    this->_table.at(index).push_back(key);
}

int Hash::_hashFunction(string x) {
    //simple mod function
    int key;
    for(int i = 0;i<x.size();i++){
        key+=x.at(i);
    }
    return key % this->_numBuckets;
}

//returns if key is found
bool Hash::find(string key) {
    int index = _hashFunction(key);
    list<string> bucket = this->_table.at(index);

    list<string>::iterator it = bucket.begin();
    while(it != bucket.end()){
        if(*it == key){
            return true;
        }
        it++;
    }
    return false;
}

bool Hash::removeItem(string key) {
    int index = _hashFunction(key);
    if(find(key)) {
        this->_table.at(index).remove(key);
        return true;
    }
    return false;
}

void Hash::displayTable() {
    for(int i = 0; i<_table.size();i++){
        list<string> bucket = this->_table.at(i);
        cout<<"index["<<i<<"]\n";
        list<string>::iterator it = bucket.begin();
        while(it != bucket.end()){
            cout<<"   "<<*it<<endl;
            it++;
        }
    }
}