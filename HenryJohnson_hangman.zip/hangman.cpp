/*
    hangman.cpp
        
    Method implementations for the hangman class.
 
    Author:

*/

#include "hangman.h"

using namespace std;

// constructor
hangman::hangman() { 
    // TODO: Read in and store words from dictionary.txt
    //decided it would take less operations to do this in start_new_game
    // TODO: Initialize game state variables

}


// start_new_game()
//
// Setup a new game of hangman.
void hangman::start_new_game(int num_guesses) {
    numGuesses = num_guesses;
    string input;
    while (_words.size()==0) {
        cout << "please enter the number of letters you would like: " << endl;
        getline(cin, input);
        numletters = atoi(input.c_str());
        readfile(numletters);
        if(_words.size()==0)cout<<"there are no words of this length"<<endl<<endl;
    }
    cout<<"would you like me to print the number of words left in the list? Y/n "<<endl;
    getline(cin, input);
    wantsNumWords = input == "Y";
    //sets current word to blank
    for(int i = 0; i<numletters; i++)currentWord+="-";

}

vector<string> hangman::readfile(int n) {
    if(n<=0)return _words;
    fstream file;
    file.open("dictionary.txt");
    string word;
    while(file>>word){
        if(word.size()==n){
            _words.push_back(word);
        }
    }
    return _words;
}


// process_guess()
//
// Process a player's guess - should return true/false depending on whether
// or not the guess was in the hidden word.  If the guess is incorrect, the
// remaining guess count is decreased.
bool hangman::process_guess(char c) {
    map<string, vector<string>> wordFamilies;
    charsGuessed.insert(c);
    //for each word in vector, create a string that contains its key: ---- filled with chars
    //add the word with the key string: ------- and value of word to a vector of words
    for(string s: _words){
        string keyTomap;
        for(char character: s){
            if(c==character){keyTomap+=c;}
            else{keyTomap+="-";}
        }
        wordFamilies[keyTomap].push_back(s);
    }
    //check which key/family has the largest vector, then set that vector as _words
    //then check if the first string in that vector contains the character
    vector<string> largestVector;
    string keyout;
    for(pair<string, vector<string>> p: wordFamilies){
        if(p.second.size()>largestVector.size()){
            largestVector = p.second;
            keyout = p.first;
        }
    }
    _words = largestVector;
    //string used to check if current word changed or not so we can return if the character
    //was in the word
    string previousWord = currentWord;
    //needs to add characters not totally replace the string
    for(int i = 0; i<numletters; i++){
        if(currentWord.at(i) == '-')currentWord.at(i)=keyout.at(i);
    }

    //prints the number of words remaining
    if(wantsNumWords)cout<<"words to select from: "<<_words.size()<<endl;

    //check if current word changed to see if a family containing the character was chosen
    if(previousWord != currentWord) {
        return true;
    }
    //de increments numguesses and returns false
    else{
        numGuesses--;
        return false;
    }
}


// get_display_word()
//
// Return a representation of the hidden word, with unguessed letters
// masked by '-' characters.
string hangman::get_display_word() {
    return currentWord;
}


// get_guesses_remaining()
//
// Return the number of guesses remaining for the player.
int hangman::get_guesses_remaining() {
    return numGuesses;
}


// get_guessed_chars()
//
// What letters has the player already guessed?  Return in alphabetic order.
string hangman::get_guessed_chars() {
    string out;
    for(char c: charsGuessed)out+=c;
    return out;
}


// was_char_guessed()
//
// Return true if letter was already guessed.
bool hangman::was_char_guessed(char c) {
    return charsGuessed.find(c)!=charsGuessed.end();
}


// is_won()
//
// Return true if the game has been won by the player.
bool hangman::is_won() {
    //current word does not have any -
    return wordFinished();
}


// is_lost()
//
// Return true if the game has been lost.
bool hangman::is_lost() {
if(!wordFinished() && numGuesses == 0) {
    cout << "the hidden word was: " << get_hidden_word()<<endl;
    return true;
}
return false;
}


//checks to sea if the word is finsished
bool hangman::wordFinished() {
    bool wordFinished = true;
    for(char c: currentWord){
        if(c == '-') wordFinished = false;
    }
    return wordFinished;
}


// get_hidden_word
//
// Return the true hidden word to show the player.
string hangman::get_hidden_word() {
    return _words.at(0);
}


