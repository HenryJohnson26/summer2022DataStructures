#ifndef _Queue_h
#define _Queue_h

/*
    Queue.h
        
    Class definition for the Queue class

    Queues assignment

    Author: Henry Johnson
*/

#include <cstdlib>

class Queue {
public:
	// max elements in queue
	static const size_t ARRAY_SZ = 5;

	Queue() {; }

	bool enqueue(char c) {
        if(is_full()){
            return false;
        }
        else{
           _data[_back]=c;
           _back ++;
           _back %= ARRAY_SZ;
           _size ++;
           return true;
        }
    }

	bool dequeue()  {
        if(is_empty()){
            return false;
        }
        else{
            _front ++;
            _front %= ARRAY_SZ;
            _size --;
            return true;
        }
    }

	char front(){
        return _data[_front];
    }

	bool is_empty(){
        return _size == 0;
    }

    bool is_full(){
        return _size==ARRAY_SZ;
    }

private:
	char _data[ARRAY_SZ];
    int _front = 0;
    int _back = 0;
    int _size = 0;
};

#endif
