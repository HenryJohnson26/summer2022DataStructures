/*
	postfix_calculator.cpp

	Implementation of the postfix calculator. 

	Author: Henry Johnson
*/

#include "postfix_calculator.h"

using namespace std;

postfix_calculator::postfix_calculator() {
}

bool postfix_calculator::evaluate(string expr) {
    string toStack;
    if(expr[expr.size()-1]!=' ')expr+=' ';
    double first;
    double second;
    for(char c: expr){
        if(c == ' '){
            if(toStack == "*"){
                _size --;
                if(_size == 0){
                    clear();
                    return false;
                }
               first = _stack.top();
               _stack.pop();
               second = _stack.top();
               _stack.pop();
               _stack.push(first*second);
            }
            else if(toStack == "/"){
                _size --;
                if(_size == 0){
                    clear();
                    return false;
                }
                first = _stack.top();
                _stack.pop();
                second = _stack.top();
                _stack.pop();
                _stack.push(second/first);
            }
            else if(toStack == "-"){
                _size --;
                if(_size == 0){
                    clear();
                    return false;
                }
                first = _stack.top();
                _stack.pop();
                second = _stack.top();
                _stack.pop();
                _stack.push(second-first);
            }
            else if(toStack == "+"){
                _size --;
                if(_size == 0){
                    clear();
                    return false;
                }
                first = _stack.top();
                _stack.pop();
                second = _stack.top();
                _stack.pop();
                _stack.push(first+second);
            }
            else if(toStack == " ")toStack = "";
            else{
                if(toStack==""){}
                else {
                    _stack.push(stod(toStack));
                    _size++;
                }
            }
            toStack = "";
        }
        else{
            toStack+=c;
        }
    }

    return true;

	// TODO: Implement as per postfix_calculator.h
	//
	// Read the comments in postfix_calculator.h for this
	// method first!  That is your guide to the required
	// functioning of this method.
	//
	// There are various ways to parse expr.  I suggest
	// you create an istringstream object, constructed on
	// expr:
	//	istringstream string_in(expr);
	// Then you can get each substring from expr using >>.
    //
    // Check each substring first to see if you have one of 
    // the four operators; if not, you can assume the value
    // is a number that you can convert to a double.  (This
    // may not be a good assumption - but we won't test you
    // on robustly handling anything other than numbers and
    // operators.)  You can use the stod() function in the
    // string library to convert strings to doubles.
}


void postfix_calculator::clear(){
    while(!_stack.empty()){
        _stack.pop();
    }
}

double postfix_calculator::top(){
    if(_stack.empty())return 0;
    else return _stack.top();
}


string postfix_calculator::to_string(){
    stack<double> out = _stack;
    while(!out.empty()){
        cout<<out.top()<<" ";
        out.pop();
    }
}
// TODO: Implement the remaining functions specified
// in postfix_calculator.h.
//
// You should start by creating "stubs" for each of
// the methods - these are methods that do nothing
// except return a value if needed.  For example, the 
// evaluate() method above does nothing but return true.
//
// Once you've got stubs for everything, then you should
// be able to compile and test the user interface.  Then
// start implementing functions, *testing constantly*!




