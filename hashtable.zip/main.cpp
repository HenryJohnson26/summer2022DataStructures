#include <iostream>
#include "hash.h"
using namespace std;

int main() {

    Hash hashtable;

    hashtable.insertItem("hello");
    hashtable.insertItem("world");
    hashtable.insertItem("122");
    hashtable.insertItem("test");
    hashtable.insertItem("with");
    hashtable.insertItem("strings");

    cout<<hashtable.find("hello")<<endl;
    hashtable.removeItem("hellow");
    cout<<hashtable.find("hello")<<endl;
    //cout<<hashtable.removeItem(103)<<endl;
    hashtable.displayTable();


    return 0;
}
